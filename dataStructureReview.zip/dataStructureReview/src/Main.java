public class Main {
    public static void main(String[] args) {
        DataStructure data = new DataStructure();

        data.addStudent("Lleyton");
        data.addStudent("Kadyn");
        data.addStudent("Brady");

        data.addAge(0,19);
        data.addAge(1,18);
        data.addAge(2,19);

        data.addMajorGPA("Computer Science", 3.54);
        data.addMajorGPA("Media Production", 3.42);
        data.addMajorGPA("Graphic Design", 3.26);

        data.addNationality("American");
        data.addNationality("English American");
        data.addNationality("British");

        data.addHomeTown("Royerton");
        data.addHomeTown("Alden");
        data.addHomeTown("Eaton");

        data.addHomeState("Indiana");
        data.addHomeState("California");
        data.addHomeState("London");

        data.printStudents();
        data.printAges();
        data.printMajors();
        data.printNationalities();
        data.printHomeTowns();
        data.printHomeStates();

        data.removeStudent("Kadyn");
        data.removeAge(1);
        data.removeMajorGPA("Media Production");
        data.removeNationality(1);
        data.removeHomeTown();
        data.removeHomeState("California");

        data.printStudents();
        data.printAges();
        data.printMajors();
        data.printNationalities();
        data.printHomeTowns();
        data.printHomeStates();
    }
}