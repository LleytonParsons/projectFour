import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
public class DataStructure {
    private ArrayList<String> studentList = new ArrayList<>();
    private int[] ageList = new int[3];
    private HashMap<String, Double> majorGpaMap = new HashMap<>();
    private LinkedList<String> nationalityList = new LinkedList<>();
    private Stack<String> hometownStack = new Stack<>();
    private Queue<String> homeStateQueue = new LinkedList<>();

    //ADD
    public void addStudent(String name){
        studentList.add(name);
    }
    public void addAge(int index, int age){
        ageList[index] = age;
    }
    public void addMajorGPA(String major, double gpa){
        majorGpaMap.put(major,gpa);
    }
    public void addNationality(String national){
        nationalityList.add(national);
    }
    public void addHomeTown(String homeTown){
        hometownStack.push(homeTown);
    }
    public void addHomeState(String homeState){
        homeStateQueue.add(homeState);
    }
    //REMOVE
    public void removeStudent(String name){
        studentList.remove(name);
    }
    public void removeAge(int index){
        ageList[index] = 0;
    }
    public void removeMajorGPA(String major){
        majorGpaMap.remove(major);
    }
    public void removeNationality(int index){
        nationalityList.remove(index);
    }
    public void removeHomeTown(){
        hometownStack.pop();
    }
    public void removeHomeState(String homeState){
        homeStateQueue.remove(homeState);
    }
    //PRINT
    public void printStudents(){
        for(int i = 0; i < studentList.size(); i++){
            System.out.println(studentList.get(i));
        }
    }
    public void printAges(){
        for(int i = 0; i < ageList.length; i++){
            System.out.println(ageList[i]);
        }
    }
    public StringBuilder printMajors(){
        StringBuilder majors = new StringBuilder();
        majorGpaMap.forEach( (major, GPA) -> {
            majors.append(String.format("Major: %s GPA: %.2f\n", major, GPA));
        });
        return majors;
    }
    public void printNationalities(){
        for(String nationality : nationalityList){
            System.out.println(nationality);
        }
    }
    public void printHomeTowns(){
        for(String homeTown : hometownStack){
            System.out.println(homeTown);
        }
    }
    public void printHomeStates(){
        System.out.println(homeStateQueue);
    }
}
