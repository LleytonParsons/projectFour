import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FlowerTest {
    private Scent sunflower = new Scent("Sunflower","Yellow",24,4.10,"Fresh");
    @Test
    void getName() {
        assertEquals("Sunflower",sunflower.getName());
    }

    @Test
    void testToString() {
        //assertEquals("Name: Sunflower\nColor: %s\nPetals: %s\nHeight: %.2f\nScent: %s\n",sunflower.toString());
        assertEquals("Scent: Fresh",sunflower.toString());
    }
}