public class Scent extends Flower{
    private String scent;

    public Scent(String name, String color, int numPetals, double height, String scent){
        super(name, color, numPetals, height);
        this.scent = scent;
    }
    public String getScent(){
        return scent;
    }
    public void setScent(String scent){
        this.scent = scent;
    }
    @Override
    public String toString(){
       // String.format("Name: %s\nColor: %s\nPetals: %s\nHeight: %.2f\nScent: %s\n", name, color, numPetals, height, scent);
        return String.format("Scent: %s", scent);
    }
}
