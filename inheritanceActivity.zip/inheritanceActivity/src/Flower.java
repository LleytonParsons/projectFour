public  class Flower {
    protected String name, color;
    protected int numPetals;
    protected double height;

    //constructor
    public Flower(String name, String color, int numPetals, double height){
        this.name = name;
        this.color = color;
        this.numPetals = numPetals;
        this.height = height;
    }
    public String getName(){
        return name;
    }
    public String getColor(){
        return color;
    }
    public int getNumPetals(){
        return numPetals;
    }
    public double getHeight(){
        return height;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setColor(String color){
        this.color = color;
    }
    public void setNumPetals(int numPetals){
        this.numPetals = numPetals;
    }
    public void setHeight(double height){
        this.height = height;
    }
    @Override
    public String toString(){
        return String.format("Name: %s\nColor: %s\nPetals: %d\nHeight: %.2f\n", name, color, numPetals, height);
    }

}