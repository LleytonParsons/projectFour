public class Population extends Flower{
    private int population;

    public Population(String name, String color, int numPetals, double height, int population){
        super(name, color, numPetals, height);
        this.population = population;
    }
    public int getPopulation(){
        return population;
    }
    public void setPopulation(int population){
        this.population = population;
    }
    @Override
    public String toString(){
        return String.format("Name: %s\nColor: %s\nPetals: %s\nHeight: %.2f\nPopulation: %d\n", name, color, numPetals, height, population);
    }
}
